# Authors and Contributors of `rows` Library

Project page: <https://github.com/turicas/rows>.

## Author/Maintainer

Created and maintained by Álvaro Justen aka turicas:

- <mailto:alvarojusten@gmail.com>
- <https://github.com/turicas>
- <https://twitter.com/turicas>


## Contributors

- Érico Andrei <https://github.com/ericof>
- Bernardo Fontes <https://github.com/berinhard>
- Alexandre Brandão (slex) <https://github.com/sxslex>
- Paulo Roberto Alves de Oliveira (aka kretcheu) <https://github.com/kretcheu>
- Jean Ferri <https://github.com/jeanferri>
- Evaldo Junior <https://github.com/infog>
- Rhenan Bartels <https://github.com/RhenanBartels>
- Mauro Baraldi <https://github.com/MauroBaraldi>
- Henrique Bastos <https://github.com/henriquebastos>
- Rômulo Collopy <https://github.com/romulocollopy>
- Davi Oliveira <https://github.com/arloc>
- Ellison Leão <https://github.com/ellisonleao>
- Ramiro Luz <https://github.com/ramiroluz>
- Humberto Rocha <https://github.com/humrochagf>
- Sebastian Oliva <https://github.com/tian2992>
- Guillermo Colmenero <https://github.com/narrowfail>
- Izabela Borges <https://github.com/izabelacborges>
- João S. O. Bueno <https://github.com/jsbueno>
- Lucas Rangel Cezimbra <https://github.com/Lrcezimbra>
- Marcelo Jorge Vieira <https://github.com/marcelometal>
- Marcos Vinícius <https://github.com/marcosvbras>
- Daniel Drumond <https://github.com/DanielDrumond>
